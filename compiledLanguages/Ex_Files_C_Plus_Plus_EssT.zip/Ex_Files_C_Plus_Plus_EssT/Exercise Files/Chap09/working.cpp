// working.cpp by Bill Weinman <http://bw.org/>
// updated 2002-06-24
#include <iostream>

int main()
{
    std::cout << "Hello, World!" << std::endl;
    return 0;
}
