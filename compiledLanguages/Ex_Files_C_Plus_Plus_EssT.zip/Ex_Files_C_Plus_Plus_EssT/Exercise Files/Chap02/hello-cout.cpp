// hello-cout.cpp by Bill Weinman [bw.org]
// updated 2020-06-24
#include <iostream>

int main()
{
    std::cout << "Hello, World!" << std::endl;
    return 0;
}
