// statement.cpp by Bill Weinman [bw.org]
// updated 2020-07-06
#include <cstdio>

int main()
{
    int x;
    x = 42;

    printf("x is %d\n", x);
    printf("x is %d\n", x = 73);

    return 0;
}
