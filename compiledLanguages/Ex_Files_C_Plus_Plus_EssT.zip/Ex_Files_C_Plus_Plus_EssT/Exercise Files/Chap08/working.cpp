// working.cpp by Bill Weinman <http://bw.org/>
// updated 2002-06-24
#include <cstdio>

int main()
{
    puts("Hello, World!");
    return 0;
}
